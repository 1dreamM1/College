﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp22
{
    public partial class Form1 : Form
    {
        string SQliteDatabasePath = "";
        private DataTable dataTable;
        private SQLiteDataAdapter dataAdapter;
        private SQLiteConnection connection;

        public Form1()
        {
            InitializeComponent();
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // выбор базы данных
        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog OpenDatabaseFileDialog = new OpenFileDialog())
            {
                OpenDatabaseFileDialog.InitialDirectory = Environment.CurrentDirectory;
                OpenDatabaseFileDialog.Title = "Откройте БД SQLite";
                OpenDatabaseFileDialog.Filter = "SQLite Databases (*.db;*.sqlite;*.sqlite3)|*.db;*.sqlite;*.sqlite3|All files (*.*)|*.*";

                if (OpenDatabaseFileDialog.ShowDialog() == DialogResult.OK)
                {
                    SQliteDatabasePath = OpenDatabaseFileDialog.FileName;
                    TextBox_Database_Path.Text = SQliteDatabasePath;
                    TextBox_Database_Name.Text = Path.GetFileName(SQliteDatabasePath);
                }
            }
        }

        // отображение базы данных
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(SQliteDatabasePath) || !File.Exists(SQliteDatabasePath))
            {
                MessageBox.Show("Выберите файл базы данных");
                return;
            }

            string DatabaseConnectionString = $"Data Source={SQliteDatabasePath};FailIfMissing=True";
            string SQLQueryExecuted = "SELECT * FROM Tasks";

            TextBox_DB_Connection_String.Text = DatabaseConnectionString;
            TextBox_SQL_Query_Executed.Text = SQLQueryExecuted;

            try
            {
                connection = new SQLiteConnection(DatabaseConnectionString);
                connection.Open();

                dataAdapter = new SQLiteDataAdapter(SQLQueryExecuted, connection);
                SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(dataAdapter);

                dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                dataAdapter.InsertCommand = commandBuilder.GetInsertCommand();
                dataAdapter.UpdateCommand = commandBuilder.GetUpdateCommand();
                dataAdapter.DeleteCommand = commandBuilder.GetDeleteCommand();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка {ex.Message}");
            }
        }

        // Добавить данные
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(SQliteDatabasePath) || !File.Exists(SQliteDatabasePath))
            {
                MessageBox.Show("Сначала выберите базу данных.");
                return;
            }

            Form2 addForm = new Form2();
            addForm.Owner = this;
            addForm.ShowDialog();
        }

        // Найти
        private void button4_Click_1(object sender, EventArgs e)
        {
            Form3 searchForm = new Form3();
            searchForm.Owner = this;
            searchForm.ShowDialog();
        }

        // Удалить выбранную запись
        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись для удаления");
                return;
            }

            DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить выбранную запись?",
                "Подтверждение удаления", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                DataRowView selectedRow = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
                selectedRow.Row.Delete();
                dataAdapter.Update(dataTable);
                RefreshData();
            }
        }

        // сохранить базу данных
        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (dataAdapter != null && dataTable != null)
            {
                dataAdapter.Update(dataTable);
                MessageBox.Show("Изменения сохранены");
            }
        }

        // метод для обновления данных после добавления
        public void RefreshData()
        {
            if (dataTable != null && dataAdapter != null)
            {
                dataTable.Clear();
                dataAdapter.Fill(dataTable);
                dataGridView1.Refresh();
            }
        }

        // Свойства для доступа к данным из Form2
        public DataTable TasksDataTable
        {
            get { return dataTable; }
        }

        public SQLiteDataAdapter TasksDataAdapter
        {
            get { return dataAdapter; }
        }

        private void TextBox_Database_Path_TextChanged(object sender, EventArgs e) { }
        private void TextBox_Database_Name_TextChanged(object sender, EventArgs e) { }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись для редактирования");
                return;
            }

            DataRowView selectedRow = (DataRowView)dataGridView1.CurrentRow.DataBoundItem;
            Form4 editForm = new Form4(selectedRow.Row);
            editForm.Owner = this;
            editForm.ShowDialog();
        }
    }
}