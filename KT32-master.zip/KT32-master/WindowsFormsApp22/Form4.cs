﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp22
{
    public partial class Form4 : Form
    {
        private DataRow editRow;

        public Form4(DataRow row)
        {
            InitializeComponent();
            editRow = row;
            LoadDataToForm();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
        }
        private void LoadDataToForm()
        {
            // Загружаем данные из выбранной строки в поля формы
            if (editRow["Title"] != DBNull.Value)
                textBox1.Text = editRow["Title"].ToString();
            if (editRow["Description"] != DBNull.Value)
                textBox2.Text = editRow["Description"].ToString();
            if (editRow["Priority"] != DBNull.Value)
                textBox3.Text = editRow["Priority"].ToString();
            if (editRow["Status"] != DBNull.Value)
                textBox4.Text = editRow["Status"].ToString();
            if (editRow["TaskType"] != DBNull.Value)
                textBox6.Text = editRow["TaskType"].ToString();
            if (editRow["CreatedDate"] != DBNull.Value)
                textBox5.Text = Convert.ToDateTime(editRow["CreatedDate"]).ToString("yyyy-MM-dd");
        }

        // сохранить
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 mainForm = this.Owner as Form1;
            if (mainForm != null && mainForm.TasksDataAdapter != null)
            {
                // обнолвение данных
                editRow["Title"] = textBox1.Text;
                editRow["Description"] = textBox2.Text;
                editRow["Priority"] = textBox3.Text;
                editRow["Status"] = textBox4.Text;
                editRow["TaskType"] = textBox6.Text;

                // сохранение
                mainForm.TasksDataAdapter.Update(mainForm.TasksDataTable);
                mainForm.RefreshData();

                MessageBox.Show("Изменения сохранены");
                this.Close();
            }
        }

        // закрыть
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}