﻿namespace WindowsFormsApp22
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Date = new System.Windows.Forms.Label();
            this.Priority = new System.Windows.Forms.Label();
            this.Description = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Label();
            this.Status = new System.Windows.Forms.Label();
            this.TaskType = new System.Windows.Forms.Label();
            this.textBox1_Title = new System.Windows.Forms.TextBox();
            this.textBox2_Description = new System.Windows.Forms.TextBox();
            this.textBox3_Priority = new System.Windows.Forms.TextBox();
            this.textBox4_Date = new System.Windows.Forms.TextBox();
            this.textBox5_Status = new System.Windows.Forms.TextBox();
            this.textBox6_TaskType = new System.Windows.Forms.TextBox();
            this.button_Add = new System.Windows.Forms.Button();
            this.button1_Close = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox6_TaskType);
            this.groupBox1.Controls.Add(this.textBox5_Status);
            this.groupBox1.Controls.Add(this.textBox4_Date);
            this.groupBox1.Controls.Add(this.textBox3_Priority);
            this.groupBox1.Controls.Add(this.textBox2_Description);
            this.groupBox1.Controls.Add(this.textBox1_Title);
            this.groupBox1.Controls.Add(this.TaskType);
            this.groupBox1.Controls.Add(this.Status);
            this.groupBox1.Controls.Add(this.Date);
            this.groupBox1.Controls.Add(this.Priority);
            this.groupBox1.Controls.Add(this.Description);
            this.groupBox1.Controls.Add(this.Title);
            this.groupBox1.Location = new System.Drawing.Point(33, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(732, 391);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Добавление записи";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(52, 241);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(104, 16);
            this.Date.TabIndex = 3;
            this.Date.Text = "Дата создания";
            this.Date.Click += new System.EventHandler(this.Date_Click);
            // 
            // Priority
            // 
            this.Priority.AutoSize = true;
            this.Priority.Location = new System.Drawing.Point(52, 177);
            this.Priority.Name = "Priority";
            this.Priority.Size = new System.Drawing.Size(79, 16);
            this.Priority.TabIndex = 2;
            this.Priority.Text = "Приоритет";
            this.Priority.Click += new System.EventHandler(this.Priority_Click);
            // 
            // Description
            // 
            this.Description.AutoSize = true;
            this.Description.Location = new System.Drawing.Point(52, 117);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(72, 16);
            this.Description.TabIndex = 1;
            this.Description.Text = "Описание";
            this.Description.Click += new System.EventHandler(this.Description_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(52, 62);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(73, 16);
            this.Title.TabIndex = 0;
            this.Title.Text = "Название";
            this.Title.Click += new System.EventHandler(this.Title_Click);
            // 
            // Status
            // 
            this.Status.AutoSize = true;
            this.Status.Location = new System.Drawing.Point(52, 296);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(53, 16);
            this.Status.TabIndex = 4;
            this.Status.Text = "Статус";
            this.Status.Click += new System.EventHandler(this.Status_Click);
            // 
            // TaskType
            // 
            this.TaskType.AutoSize = true;
            this.TaskType.Location = new System.Drawing.Point(52, 357);
            this.TaskType.Name = "TaskType";
            this.TaskType.Size = new System.Drawing.Size(83, 16);
            this.TaskType.TabIndex = 5;
            this.TaskType.Text = "Тип задачи";
            this.TaskType.Click += new System.EventHandler(this.TaskType_Click);
            // 
            // textBox1_Title
            // 
            this.textBox1_Title.Location = new System.Drawing.Point(265, 62);
            this.textBox1_Title.Name = "textBox1_Title";
            this.textBox1_Title.Size = new System.Drawing.Size(427, 22);
            this.textBox1_Title.TabIndex = 6;
            this.textBox1_Title.TextChanged += new System.EventHandler(this.textBox1_Title_TextChanged);
            // 
            // textBox2_Description
            // 
            this.textBox2_Description.Location = new System.Drawing.Point(265, 117);
            this.textBox2_Description.Name = "textBox2_Description";
            this.textBox2_Description.Size = new System.Drawing.Size(427, 22);
            this.textBox2_Description.TabIndex = 7;
            this.textBox2_Description.TextChanged += new System.EventHandler(this.textBox2_Description_TextChanged);
            // 
            // textBox3_Priority
            // 
            this.textBox3_Priority.Location = new System.Drawing.Point(265, 177);
            this.textBox3_Priority.Name = "textBox3_Priority";
            this.textBox3_Priority.Size = new System.Drawing.Size(427, 22);
            this.textBox3_Priority.TabIndex = 8;
            this.textBox3_Priority.TextChanged += new System.EventHandler(this.textBox3_Priority_TextChanged);
            // 
            // textBox4_Date
            // 
            this.textBox4_Date.Location = new System.Drawing.Point(265, 241);
            this.textBox4_Date.Name = "textBox4_Date";
            this.textBox4_Date.Size = new System.Drawing.Size(427, 22);
            this.textBox4_Date.TabIndex = 9;
            this.textBox4_Date.TextChanged += new System.EventHandler(this.textBox4_Date_TextChanged);
            // 
            // textBox5_Status
            // 
            this.textBox5_Status.Location = new System.Drawing.Point(265, 296);
            this.textBox5_Status.Name = "textBox5_Status";
            this.textBox5_Status.Size = new System.Drawing.Size(427, 22);
            this.textBox5_Status.TabIndex = 10;
            this.textBox5_Status.TextChanged += new System.EventHandler(this.textBox5_Status_TextChanged);
            // 
            // textBox6_TaskType
            // 
            this.textBox6_TaskType.Location = new System.Drawing.Point(265, 357);
            this.textBox6_TaskType.Name = "textBox6_TaskType";
            this.textBox6_TaskType.Size = new System.Drawing.Size(427, 22);
            this.textBox6_TaskType.TabIndex = 11;
            this.textBox6_TaskType.TextChanged += new System.EventHandler(this.textBox6_TaskType_TextChanged);
            // 
            // button_Add
            // 
            this.button_Add.Location = new System.Drawing.Point(115, 447);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(163, 50);
            this.button_Add.TabIndex = 1;
            this.button_Add.Text = "Добавить";
            this.button_Add.UseVisualStyleBackColor = true;
            this.button_Add.Click += new System.EventHandler(this.button_Add_Click);
            // 
            // button1_Close
            // 
            this.button1_Close.Location = new System.Drawing.Point(483, 447);
            this.button1_Close.Name = "button1_Close";
            this.button1_Close.Size = new System.Drawing.Size(163, 50);
            this.button1_Close.TabIndex = 2;
            this.button1_Close.Text = "Закрыть";
            this.button1_Close.UseVisualStyleBackColor = true;
            this.button1_Close.Click += new System.EventHandler(this.button1_Close_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 537);
            this.Controls.Add(this.button1_Close);
            this.Controls.Add(this.button_Add);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label Priority;
        private System.Windows.Forms.Label Description;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label TaskType;
        private System.Windows.Forms.Label Status;
        private System.Windows.Forms.TextBox textBox6_TaskType;
        private System.Windows.Forms.TextBox textBox5_Status;
        private System.Windows.Forms.TextBox textBox4_Date;
        private System.Windows.Forms.TextBox textBox3_Priority;
        private System.Windows.Forms.TextBox textBox2_Description;
        private System.Windows.Forms.TextBox textBox1_Title;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Button button1_Close;
    }
}