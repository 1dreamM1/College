﻿namespace WindowsFormsApp22
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.TextBox_Database_Path = new System.Windows.Forms.TextBox();
            this.TextBox_Database_Name = new System.Windows.Forms.TextBox();
            this.TextBox_DB_Connection_String = new System.Windows.Forms.TextBox();
            this.TextBox_SQL_Query_Executed = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1039, 344);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(273, 374);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(188, 99);
            this.button1.TabIndex = 1;
            this.button1.Text = "Выберите базу данных";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(564, 374);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(188, 99);
            this.button2.TabIndex = 2;
            this.button2.Text = "Отобразить БД";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // TextBox_Database_Path
            // 
            this.TextBox_Database_Path.Location = new System.Drawing.Point(69, 374);
            this.TextBox_Database_Path.Name = "TextBox_Database_Path";
            this.TextBox_Database_Path.Size = new System.Drawing.Size(100, 22);
            this.TextBox_Database_Path.TabIndex = 3;
            this.TextBox_Database_Path.Visible = false;
            this.TextBox_Database_Path.TextChanged += new System.EventHandler(this.TextBox_Database_Path_TextChanged);
            // 
            // TextBox_Database_Name
            // 
            this.TextBox_Database_Name.Location = new System.Drawing.Point(69, 402);
            this.TextBox_Database_Name.Name = "TextBox_Database_Name";
            this.TextBox_Database_Name.Size = new System.Drawing.Size(100, 22);
            this.TextBox_Database_Name.TabIndex = 4;
            this.TextBox_Database_Name.TextChanged += new System.EventHandler(this.TextBox_Database_Name_TextChanged);
            // 
            // TextBox_DB_Connection_String
            // 
            this.TextBox_DB_Connection_String.Location = new System.Drawing.Point(860, 383);
            this.TextBox_DB_Connection_String.Name = "TextBox_DB_Connection_String";
            this.TextBox_DB_Connection_String.Size = new System.Drawing.Size(100, 22);
            this.TextBox_DB_Connection_String.TabIndex = 5;
            this.TextBox_DB_Connection_String.Visible = false;
            // 
            // TextBox_SQL_Query_Executed
            // 
            this.TextBox_SQL_Query_Executed.Location = new System.Drawing.Point(860, 421);
            this.TextBox_SQL_Query_Executed.Name = "TextBox_SQL_Query_Executed";
            this.TextBox_SQL_Query_Executed.Size = new System.Drawing.Size(100, 22);
            this.TextBox_SQL_Query_Executed.TabIndex = 6;
            this.TextBox_SQL_Query_Executed.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1161, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(188, 99);
            this.button3.TabIndex = 7;
            this.button3.Text = "Добавить данные";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(1161, 183);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(188, 99);
            this.SaveButton.TabIndex = 8;
            this.SaveButton.Text = "Сохранить БД";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(825, 374);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(188, 99);
            this.button4.TabIndex = 9;
            this.button4.Text = "Найти";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1254, 374);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(188, 99);
            this.button5.TabIndex = 10;
            this.button5.Text = "Удалить выбранную запись";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.Location = new System.Drawing.Point(1040, 374);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(188, 99);
            this.buttonEdit.TabIndex = 11;
            this.buttonEdit.Text = "Редактировать запись";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1454, 485);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.TextBox_SQL_Query_Executed);
            this.Controls.Add(this.TextBox_DB_Connection_String);
            this.Controls.Add(this.TextBox_Database_Name);
            this.Controls.Add(this.TextBox_Database_Path);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox TextBox_Database_Path;
        private System.Windows.Forms.TextBox TextBox_Database_Name;
        private System.Windows.Forms.TextBox TextBox_DB_Connection_String;
        private System.Windows.Forms.TextBox TextBox_SQL_Query_Executed;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button buttonEdit;
    }
}

