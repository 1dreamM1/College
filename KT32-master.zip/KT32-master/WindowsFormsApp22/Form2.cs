﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp22
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            textBox4_Date.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }

        // button_Add_Click - Добавить введенные данные
        private void button_Add_Click(object sender, EventArgs e)
        {
            Form1 mainForm = this.Owner as Form1;
            if (mainForm != null && mainForm.TasksDataTable != null && mainForm.TasksDataAdapter != null)
            {
                DataRow newRow = mainForm.TasksDataTable.NewRow();

                newRow["Title"] = textBox1_Title.Text;
                newRow["Description"] = textBox2_Description.Text;
                newRow["Priority"] = textBox3_Priority.Text;
                newRow["Status"] = textBox5_Status.Text;
                newRow["TaskType"] = textBox6_TaskType.Text;
                newRow["CreatedDate"] = DateTime.Now;

                mainForm.TasksDataTable.Rows.Add(newRow);
                mainForm.TasksDataAdapter.Update(mainForm.TasksDataTable);

                MessageBox.Show("Задача успешно добавлена");

                textBox1_Title.Text = "";
                textBox2_Description.Text = "";
                textBox3_Priority.Text = "";
                textBox4_Date.Text = DateTime.Now.ToString("yyyy-MM-dd");
                textBox5_Status.Text = "";
                textBox6_TaskType.Text = "";

                mainForm.RefreshData();
            }
        }

        // button1_Close_Click - Закрыть
        private void button1_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Остальные методы
        private void Form2_Load(object sender, EventArgs e) 
        { 

        }
        private void groupBox1_Enter(object sender, EventArgs e) 
        { 

        }
        private void Title_Click(object sender, EventArgs e) 
        { 
        
        }
        private void textBox1_Title_TextChanged(object sender, EventArgs e) 
        { 
        
        }
        private void Description_Click(object sender, EventArgs e) 
        { 
        
        }
        private void textBox2_Description_TextChanged(object sender, EventArgs e) 
        { 
        
        }
        private void Priority_Click(object sender, EventArgs e) 
        { 
        
        }
        private void textBox3_Priority_TextChanged(object sender, EventArgs e) 
        { 
        
        }
        private void Date_Click(object sender, EventArgs e) 
        { 
        
        }
        private void textBox4_Date_TextChanged(object sender, EventArgs e) 
        { 
        
        }
        private void Status_Click(object sender, EventArgs e) 
        { 
        
        }
        private void textBox5_Status_TextChanged(object sender, EventArgs e) 
        { 
        
        }
        private void TaskType_Click(object sender, EventArgs e) 
        { 
        
        }
        private void textBox6_TaskType_TextChanged(object sender, EventArgs e) 
        { 
        
        }
    }
}