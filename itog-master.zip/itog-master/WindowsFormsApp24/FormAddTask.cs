﻿using System;
using System.Windows.Forms;

namespace TaskManager
{
    public partial class FormAddTask : Form
    {
        private TaskManager taskManager;
        private Task editingTask;
        private bool isEditMode;

        // Конструктор для добавления новой задачи
        public FormAddTask()
        {
            InitializeComponent();
            taskManager = new TaskManager();
            isEditMode = false;
            this.Text = "Добавить задачу";
        }

        // Конструктор для редактирования задачи
        public FormAddTask(Task task)
        {
            InitializeComponent();
            taskManager = new TaskManager();
            editingTask = task;
            isEditMode = true;
            this.Text = "Редактировать задачу";
        }

        private void FormAddTask_Load(object sender, EventArgs e)
        {
            // Приоритеты
            comboPriority.Items.Clear();
            comboPriority.Items.AddRange(new object[] {
                "Высокий",
                "Средний",
                "Низкий"
            });

            // Статусы
            comboStatus.Items.Clear();
            comboStatus.Items.AddRange(new object[] {
                "Не начата",
                "В процессе",
                "Завершена"
            });

            // Дефолтные значения
            comboPriority.SelectedIndex = 1;
            comboStatus.SelectedIndex = 0;

            // Если режим редактирования - заполняем поля
            if (isEditMode && editingTask != null)
            {
                txtTitle.Text = editingTask.Title;
                txtDescription.Text = editingTask.Description;

                // Защита от выхода за пределы массива
                if (editingTask.Priority >= 1 && editingTask.Priority <= 3)
                    comboPriority.SelectedIndex = editingTask.Priority - 1;

                if (editingTask.Status == "NotStarted") comboStatus.SelectedIndex = 0;
                else if (editingTask.Status == "InProgress") comboStatus.SelectedIndex = 1;
                else if (editingTask.Status == "Completed") comboStatus.SelectedIndex = 2;

                btnSave.Text = "Сохранить";
            }
            else
            {
                btnSave.Text = "Добавить";
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Проверка заполнения
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Введите название задачи!");
                txtTitle.Focus();
                return;
            }

            string[] statuses = { "NotStarted", "InProgress", "Completed" };

            // Создание или обновление задачи
            if (isEditMode)
            {
                editingTask.Title = txtTitle.Text.Trim();
                editingTask.Description = txtDescription.Text.Trim();
                editingTask.Priority = comboPriority.SelectedIndex + 1;
                editingTask.Status = statuses[comboStatus.SelectedIndex];

                taskManager.UpdateTask(editingTask);
                MessageBox.Show("Задача обновлена!");
            }
            else
            {
                Task newTask = new Task
                {
                    Title = txtTitle.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    Priority = comboPriority.SelectedIndex + 1,
                    Status = statuses[comboStatus.SelectedIndex],
                    ListId = 1
                };

                taskManager.AddTask(newTask);
                MessageBox.Show("Задача добавлена!");
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void labelTitle_Click(object sender, EventArgs e)
        {

        }

        private void panelTop_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}