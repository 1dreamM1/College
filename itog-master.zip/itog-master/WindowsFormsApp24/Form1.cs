﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using System.IO;

namespace TaskManager
{
    public partial class Form1 : Form
    {
        private TaskManager taskManager;
        private List<Task> currentTasks;

        public Form1()
        {
            InitializeComponent();
            taskManager = new TaskManager();
            currentTasks = new List<Task>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Database.CheckDatabaseExists() == false)
            {
                MessageBox.Show("Файл TaskManager.db не найден!");
                Application.Exit();
                return;
            }

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
            dataGridView1.ReadOnly = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.RowHeadersVisible = false;

            comboBoxFilter.Items.AddRange(new object[] {
                "Все задачи", "Активные", "Завершённые",
                "Высокий приоритет", "Средний приоритет", "Низкий приоритет"
            });
            comboBoxFilter.SelectedIndex = 1;

            LoadTasks();
        }

        private void LoadTasks()
        {
            string filter = comboBoxFilter.SelectedItem.ToString();

            if (filter.Contains("Все"))
                currentTasks = taskManager.GetAllTasks();
            else if (filter.Contains("Активные"))
                currentTasks = taskManager.GetTasksByStatus("NotStarted", "InProgress");
            else if (filter.Contains("Завершённые"))
                currentTasks = taskManager.GetTasksByStatus("Completed");
            else if (filter.Contains("Высокий"))
                currentTasks = taskManager.GetTasksByPriority(1);
            else if (filter.Contains("Средний"))
                currentTasks = taskManager.GetTasksByPriority(2);
            else if (filter.Contains("Низкий"))
                currentTasks = taskManager.GetTasksByPriority(3);

            DisplayTasks();
        }

        private void DisplayTasks()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = currentTasks;

            if (dataGridView1.Columns.Count > 0)
            {
                dataGridView1.Columns["Id"].Visible = false;
                dataGridView1.Columns["ListId"].Visible = false;
                dataGridView1.Columns["DueDate"].Visible = false;
                dataGridView1.Columns["CompletedDate"].Visible = false;
                dataGridView1.Columns["IsDeleted"].Visible = false;

                dataGridView1.Columns["Title"].HeaderText = "Название";
                dataGridView1.Columns["Description"].HeaderText = "Описание";
                dataGridView1.Columns["Status"].HeaderText = "Статус";
                dataGridView1.Columns["Priority"].HeaderText = "Приоритет";
                dataGridView1.Columns["CreatedDate"].HeaderText = "Создано";
            }

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (i < currentTasks.Count)
                {
                    DataGridViewRow row = dataGridView1.Rows[i];
                    Task task = currentTasks[i];

                    if (task.Status == "Completed")
                    {
                        row.DefaultCellStyle.BackColor = Color.LightGreen;
                        row.DefaultCellStyle.Font = new Font(dataGridView1.Font, FontStyle.Strikeout);
                    }
                    else if (task.Priority == 1)
                        row.DefaultCellStyle.BackColor = Color.LightCoral;
                    else if (task.Priority == 2)
                        row.DefaultCellStyle.BackColor = Color.LightYellow;
                }
            }

            TaskStatistics stats = taskManager.GetStatistics();
            labelTotal.Text = "Всего: " + stats.Total;
            labelActive.Text = "Активных: " + stats.Active;
            labelCompleted.Text = "Завершено: " + stats.Completed;
            labelPercent.Text = "Прогресс: " + stats.CompletionRate.ToString("F0") + "%";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FormAddTask form = new FormAddTask();
            if (form.ShowDialog() == DialogResult.OK)
                LoadTasks();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите задачу!");
                return;
            }

            Task task = currentTasks[dataGridView1.SelectedRows[0].Index];
            FormAddTask form = new FormAddTask(task);
            if (form.ShowDialog() == DialogResult.OK)
                LoadTasks();
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите задачу!");
                return;
            }

            Task task = currentTasks[dataGridView1.SelectedRows[0].Index];

            if (task.Status == "Completed")
            {
                taskManager.ChangeStatus(task.Id, "InProgress");
                MessageBox.Show("Задача возобновлена!", "Успех");
            }
            else
            {
                taskManager.CompleteTask(task.Id);
                MessageBox.Show("Задача завершена!", "Успех");
            }

            LoadTasks();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите задачу!");
                return;
            }

            if (MessageBox.Show("Удалить задачу?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Task task = currentTasks[dataGridView1.SelectedRows[0].Index];
                taskManager.DeleteTask(task.Id);
                MessageBox.Show("Задача удалена!", "Успех");
                LoadTasks();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text.Trim()))
                LoadTasks();
            else
            {
                currentTasks = taskManager.SearchTasks(txtSearch.Text.Trim());
                DisplayTasks();
            }
        }

        private void comboBoxFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadTasks();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                btnEdit_Click(sender, e);
        }

        private void panelTop_Paint(object sender, PaintEventArgs e) 
        { 
        
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) 
        { 
        
        }
        private void txtSearch_TextChanged(object sender, EventArgs e) 
        { 
        
        }
        private void panelSearch_Paint(object sender, PaintEventArgs e) 
        { 
        
        }
        private void labelFilter_Click(object sender, EventArgs e) 
        { 
        
        }
        private void label4_Click(object sender, EventArgs e) 
        { 
        
        }
    }

    public class Database
    {
        private string connectionString;

        public Database()
        {
            string dbPath = Path.Combine(Application.StartupPath, "TaskManager.db");
            connectionString = "Data Source=" + dbPath + ";";
        }

        public static bool CheckDatabaseExists()
        {
            string dbPath = Path.Combine(Application.StartupPath, "TaskManager.db");
            return File.Exists(dbPath);
        }

        public SqliteConnection GetConnection()
        {
            SqliteConnection conn = new SqliteConnection(connectionString);
            conn.Open();
            return conn;
        }
    }

    public class Task
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int ListId { get; set; }
        public int Priority { get; set; }
        public string Status { get; set; }
        public string DueDate { get; set; }
        public string CreatedDate { get; set; }
        public string CompletedDate { get; set; }
        public int IsDeleted { get; set; }

        public Task()
        {
            Status = "NotStarted";
            Priority = 2;
            ListId = 1;
            CreatedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            IsDeleted = 0;
        }
    }
    public class TaskManager
    {
        private Database db;

        public TaskManager()
        {
            db = new Database();
        }

        public void AddTask(Task task)
        {
            SqliteConnection conn = db.GetConnection();
            string query = "INSERT INTO Tasks (Title, Description, ListID, Priority, Status, CreatedDate, IsDeleted) VALUES (@title, @desc, @listId, @priority, @status, @created, 0)";
            SqliteCommand cmd = new SqliteCommand(query, conn);

            cmd.Parameters.AddWithValue("@title", task.Title);
            cmd.Parameters.AddWithValue("@desc", task.Description == null ? "" : task.Description);
            cmd.Parameters.AddWithValue("@listId", task.ListId);
            cmd.Parameters.AddWithValue("@priority", task.Priority);
            cmd.Parameters.AddWithValue("@status", task.Status);
            cmd.Parameters.AddWithValue("@created", task.CreatedDate);

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void UpdateTask(Task task)
        {
            SqliteConnection conn = db.GetConnection();
            string query = "UPDATE Tasks SET Title=@title, Description=@desc, Priority=@priority, Status=@status WHERE ID=@id";
            SqliteCommand cmd = new SqliteCommand(query, conn);

            cmd.Parameters.AddWithValue("@title", task.Title);
            cmd.Parameters.AddWithValue("@desc", task.Description == null ? "" : task.Description);
            cmd.Parameters.AddWithValue("@priority", task.Priority);
            cmd.Parameters.AddWithValue("@status", task.Status);
            cmd.Parameters.AddWithValue("@id", task.Id);

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void CompleteTask(int taskId)
        {
            SqliteConnection conn = db.GetConnection();
            string query = "UPDATE Tasks SET Status='Completed', CompletedDate=@completed WHERE ID=@id";
            SqliteCommand cmd = new SqliteCommand(query, conn);

            cmd.Parameters.AddWithValue("@completed", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.Parameters.AddWithValue("@id", taskId);

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void ChangeStatus(int taskId, string newStatus)
        {
            SqliteConnection conn = db.GetConnection();
            string query = "UPDATE Tasks SET Status=@status WHERE ID=@id";
            SqliteCommand cmd = new SqliteCommand(query, conn);

            cmd.Parameters.AddWithValue("@status", newStatus);
            cmd.Parameters.AddWithValue("@id", taskId);

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void DeleteTask(int taskId)
        {
            SqliteConnection conn = db.GetConnection();
            string query = "UPDATE Tasks SET IsDeleted=1 WHERE ID=@id";
            SqliteCommand cmd = new SqliteCommand(query, conn);

            cmd.Parameters.AddWithValue("@id", taskId);

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public List<Task> GetAllTasks()
        {
            return ExecuteQuery("SELECT * FROM Tasks WHERE IsDeleted=0 ORDER BY Priority, ID DESC");
        }

        public List<Task> GetTasksByStatus(string status1, string status2)
        {
            return ExecuteQuery("SELECT * FROM Tasks WHERE (Status='" + status1 + "' OR Status='" + status2 + "') AND IsDeleted=0 ORDER BY Priority, ID DESC");
        }

        public List<Task> GetTasksByStatus(string status)
        {
            return ExecuteQuery("SELECT * FROM Tasks WHERE Status='" + status + "' AND IsDeleted=0 ORDER BY Priority, ID DESC");
        }

        public List<Task> GetTasksByPriority(int priority)
        {
            return ExecuteQuery("SELECT * FROM Tasks WHERE Priority=" + priority + " AND IsDeleted=0 ORDER BY ID DESC");
        }

        public List<Task> SearchTasks(string searchText)
        {
            SqliteConnection conn = db.GetConnection();
            string query = "SELECT * FROM Tasks WHERE (Title LIKE @search OR Description LIKE @search) AND IsDeleted=0 ORDER BY Priority, ID DESC";
            SqliteCommand cmd = new SqliteCommand(query, conn);

            cmd.Parameters.AddWithValue("@search", "%" + searchText + "%");

            List<Task> tasks = ReadTasks(cmd);
            conn.Close();
            return tasks;
        }

        public TaskStatistics GetStatistics()
        {
            TaskStatistics stats = new TaskStatistics();
            SqliteConnection conn = db.GetConnection();

            SqliteCommand cmd1 = new SqliteCommand("SELECT COUNT(*) FROM Tasks WHERE IsDeleted=0", conn);
            stats.Total = Convert.ToInt32(cmd1.ExecuteScalar());

            SqliteCommand cmd2 = new SqliteCommand("SELECT COUNT(*) FROM Tasks WHERE (Status='NotStarted' OR Status='InProgress') AND IsDeleted=0", conn);
            stats.Active = Convert.ToInt32(cmd2.ExecuteScalar());

            SqliteCommand cmd3 = new SqliteCommand("SELECT COUNT(*) FROM Tasks WHERE Status='Completed' AND IsDeleted=0", conn);
            stats.Completed = Convert.ToInt32(cmd3.ExecuteScalar());

            if (stats.Total > 0)
                stats.CompletionRate = (double)stats.Completed / (double)stats.Total * 100.0;
            else
                stats.CompletionRate = 0;

            conn.Close();
            return stats;
        }

        private List<Task> ExecuteQuery(string query)
        {
            SqliteConnection conn = db.GetConnection();
            SqliteCommand cmd = new SqliteCommand(query, conn);
            List<Task> tasks = ReadTasks(cmd);
            conn.Close();
            return tasks;
        }

        private List<Task> ReadTasks(SqliteCommand cmd)
        {
            List<Task> tasks = new List<Task>();
            SqliteDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Task task = new Task();
                task.Id = reader.GetInt32(0);
                task.Title = reader.GetString(1);
                task.Description = reader.IsDBNull(2) ? "" : reader.GetString(2);
                task.ListId = reader.IsDBNull(3) ? 1 : reader.GetInt32(3);
                task.Priority = reader.GetInt32(4);
                task.Status = reader.GetString(5);
                task.DueDate = reader.IsDBNull(6) ? null : reader.GetString(6);
                task.CreatedDate = reader.IsDBNull(7) ? DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") : reader.GetString(7);
                task.CompletedDate = reader.IsDBNull(8) ? null : reader.GetString(8);
                task.IsDeleted = reader.IsDBNull(9) ? 0 : reader.GetInt32(9);
                tasks.Add(task);
            }

            reader.Close();
            return tasks;
        }
    }

    public class TaskStatistics
    {
        public int Total { get; set; }
        public int Active { get; set; }
        public int Completed { get; set; }
        public double CompletionRate { get; set; }
    }
}