﻿using System;
using System.Windows.Forms;
using TaskManager; // [Исправление 1] Добавлено, чтобы видеть Form1

namespace TaskManager // [Исправление 2] Приведено к единому пространству имен
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}