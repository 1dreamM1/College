﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadFlights();
            LoadTickets();
        }

        // создаем словарь и лист
        private Dictionary<int, Flight> flights = new Dictionary<int, Flight>();
        private List<Ticket> tickets = new List<Ticket>();

        // свойства классов
        public class Flight
        {
            public int Number { get; set; }
            public string SendPoint { get; set; }
            public int FlightTime { get; set; }
            public int PlacesNumber { get; set; }
        }

        public class Ticket
        {
            public int TicketNumber { get; set; }
            public int FlightNumber { get; set; }
            public int Place { get; set; }
            public string FlightDate { get; set; }
            public string Destination { get; set; }
            public string DestinationDate { get; set; }
            public int DestinationTime { get; set; }
            public double Price { get; set; }
            public string SellDate { get; set; }
        }
        // методы для кнопок
        private void LoadFlights()
        {
            listBox1.Items.Clear();
            flights.Clear();

            using (StreamReader reader = new StreamReader("Flight.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    Flight flight = new Flight
                    {
                        Number = int.Parse(parts[0]),
                        SendPoint = parts[1],
                        FlightTime = int.Parse(parts[2]),
                        PlacesNumber = int.Parse(parts[3])
                    };
                    flights[flight.Number] = flight;
                    listBox1.Items.Add($"Рейс {flight.Number}: {flight.SendPoint} - {flight.FlightTime}:00");
                }
            }
        }

        private void LoadTickets()
        {
            listBox2.Items.Clear();
            tickets.Clear();

            using (StreamReader reader = new StreamReader("Tickets.txt"))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    Ticket ticket = new Ticket
                    {
                        TicketNumber = int.Parse(parts[0]),
                        FlightNumber = int.Parse(parts[1]),
                        Place = int.Parse(parts[2]),
                        FlightDate = parts[3],
                        Destination = parts[4],
                        DestinationDate = parts[5],
                        DestinationTime = int.Parse(parts[6]),
                        Price = double.Parse(parts[7]),
                        SellDate = parts[8]
                    };
                    tickets.Add(ticket);
                    listBox2.Items.Add($"Билет {ticket.TicketNumber}: рейс {ticket.FlightNumber}");
                }
            }
        }

        // кнопка Поиск рейсов
        private void button1_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();

            var periods = new Dictionary<int, int>();
            foreach (var ticket in tickets)
            {
                if (flights.ContainsKey(ticket.FlightNumber))
                {
                    int period = ticket.DestinationTime - flights[ticket.FlightNumber].FlightTime;
                    if (period < 0) period += 24;

                    if (!periods.ContainsKey(ticket.FlightNumber) || period > periods[ticket.FlightNumber])
                        periods[ticket.FlightNumber] = period;
                }
            }

            if (periods.Count > 0)
            {
                int maxPeriod = 0;
                foreach (int period in periods.Values)
                {
                    if (period > maxPeriod)
                        maxPeriod = period;
                }

                listBox3.Items.Add($"Макс. продолжительность: {maxPeriod}ч");

                foreach (var flight in periods)
                {
                    if (flight.Value == maxPeriod)
                        listBox3.Items.Add($"Рейс {flight.Key}");
                }
            }
        }

        // кнопка Подсчет пассажиров
        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int time) && time >= 0 && time <= 23)
            {
                int count = 0;
                foreach (var ticket in tickets)
                {
                    if (flights.ContainsKey(ticket.FlightNumber) &&
                        flights[ticket.FlightNumber].FlightTime == time)
                    {
                        count++;
                    }
                }

                listBox3.Items.Clear();
                listBox3.Items.Add($"Пассажиров в {time}:00: {count}");
            }
        }

        // кнопка Обновить данные
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            flights.Clear();
            tickets.Clear();
            LoadFlights();
            LoadTickets();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}