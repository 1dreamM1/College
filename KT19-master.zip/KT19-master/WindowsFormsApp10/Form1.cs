﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                pictureBox1.Image = Properties.Resources.triangle;
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.Image = Properties.Resources.square;
            } 
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0 && comboBox1.SelectedIndex == 0)
            {
                pictureBox1.Image = Properties.Resources.triangle_green;
            }
            else if (comboBox2.SelectedIndex == 1 && comboBox1.SelectedIndex == 0)
            {
                pictureBox1.Image = Properties.Resources.triangle_blue;
            }
            else if (comboBox2.SelectedIndex == 2 && comboBox1.SelectedIndex == 0) { 
                pictureBox1.Image= Properties.Resources.triangle_red;
            }
            else if (comboBox2.SelectedIndex == 0 && comboBox1.SelectedIndex == 1)
            {
                pictureBox1.Image = Properties.Resources.square_green;
            }
            else if (comboBox2.SelectedIndex == 1 && comboBox1.SelectedIndex == 1)
            {
                pictureBox1.Image = Properties.Resources.square_blue;
            }
            else if (comboBox2.SelectedIndex == 2 && comboBox1.SelectedIndex == 1)
            {
                pictureBox1.Image = Properties.Resources.square_red;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
