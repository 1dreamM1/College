﻿using System;
namespace ZooLibrary
{
    public class Animal
    {
        protected string _animalType;
        protected int _age;
        protected string _breed;

        public void AnimalData(string animalType, int age, string breed)
        {
            _animalType = animalType;
            _age = age;
            _breed = breed;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Животное: {_animalType}");
            Console.WriteLine($"Порода: {_breed}");
            Console.WriteLine($"Возраст: {_age}");
        }
    }

    public class Dog : Animal
    {
        public void Display()
        {
            Console.WriteLine($"Собака породы {_breed}, возраст: {_age}");
        }
    }
}