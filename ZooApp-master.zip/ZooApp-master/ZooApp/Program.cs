﻿using System;
using ZooLibrary;

namespace ZooApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dog dog = new Dog();
            dog.AnimalData("Собака", 5, "Хаски");
            dog.PrintInfo();
            dog.Display();

            Console.ReadLine();
        }
    }
}