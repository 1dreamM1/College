﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int a = 50;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = $"До конца занятия осталось {a} минут";
            System.Threading.Timer timer = new System.Threading.Timer(Callback, null, 0, 300000);
        }

        public async void Callback(object obj)
        {
            if (a != 0) {
                a -= 5;
            }
            await Task.Run(() =>
            {
                if (label1.InvokeRequired)
                {
                    label1.Invoke(new Action(() =>
                    {
                        label1.Text = $"До конца занятия осталось {a} минут";
                        label1.Invalidate();
                        label1.Update();
                    }));
                }
            });
        }
    }
}
